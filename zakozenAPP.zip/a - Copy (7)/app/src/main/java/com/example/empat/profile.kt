package com.example.empat

import android.content.Intent
import android.os.Bundle
import android.widget.LinearLayout
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.bottomnavigation.BottomNavigationView

class profile : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_profile)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        //navigasi
        val home = findViewById<LinearLayout>(R.id.home1)
        home.setOnClickListener {
            Intent(this,MainActivity::class.java).also {
                startActivity(it)
            }
        }
        val lk = findViewById<LinearLayout>(R.id.lk)
        lk.setOnClickListener {
            Intent(this,like::class.java).also {
                startActivity(it)
            }
        }
        val qr = findViewById<LinearLayout>(R.id.qr)
        qr.setOnClickListener {
            Intent(this,qrc::class.java).also {
                startActivity(it)
            }
        }
        val prf = findViewById<LinearLayout>(R.id.prf)
        prf.setOnClickListener {
            Intent(this,profile::class.java).also {
                startActivity(it)
            }
        }
    }
}