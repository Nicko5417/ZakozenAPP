package com.example.empat

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class sepatu : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_sepatu)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.sepatu)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        val kembali = findViewById<Button>(R.id.btnKembalii)

        kembali.setOnClickListener{
            Intent(this,MainActivity::class.java).also {
                startActivity(it)
            }
        }
        val gambar1 = findViewById<LinearLayout>(R.id.imageBarang)
        val item1 = findViewById<TextView>(R.id.barang1)
        val harga1 = findViewById<TextView>(R.id.hargaDetail)

        val gambar2 = findViewById<LinearLayout>(R.id.imageBarang2)
        val item2 = findViewById<TextView>(R.id.barang2)
        val harga2 = findViewById<TextView>(R.id.hargaDetail2)

        val gambar3 = findViewById<LinearLayout>(R.id.imageBarang3)
        val item3 = findViewById<TextView>(R.id.barang3)
        val harga3 = findViewById<TextView>(R.id.hargaDetail3)

        val gambar4 = findViewById<LinearLayout>(R.id.imageBarang4)
        val item4 = findViewById<TextView>(R.id.barang4)
        val harga4 = findViewById<TextView>(R.id.hargaDetail4)

        val gambar5 = findViewById<LinearLayout>(R.id.imageBarang5)
        val item5 = findViewById<TextView>(R.id.barang5)
        val harga5 = findViewById<TextView>(R.id.hargaDetail5)

        val gambar6 = findViewById<LinearLayout>(R.id.imageBarang6)
        val item6 = findViewById<TextView>(R.id.barang6)
        val harga6 = findViewById<TextView>(R.id.hargaDetail6)

        val gambar7 = findViewById<LinearLayout>(R.id.imageBarang7)
        val item7 = findViewById<TextView>(R.id.barang7)
        val harga7 = findViewById<TextView>(R.id.hargaDetail7)

        val gambar8 = findViewById<LinearLayout>(R.id.imageBarang8)
        val item8 = findViewById<TextView>(R.id.barang8)
        val harga8 = findViewById<TextView>(R.id.hargaDetail8)

        //bagian1
        gambar1.setOnClickListener {
            val intent = Intent(this, shopping::class.java)
            intent.putExtra("NAMA_ITEM", item1.text.toString())
            intent.putExtra("HARGA_ITEM", harga1.text.toString())
            intent.putExtra("GAMBAR_ITEM", R.drawable.sepatu)
            startActivity(intent)
        }
        //bagian 2
        gambar2.setOnClickListener {
            val intent = Intent(this, shopping::class.java)
            intent.putExtra("NAMA_ITEM", item2.text.toString())
            intent.putExtra("HARGA_ITEM", harga2.text.toString())
            intent.putExtra("GAMBAR_ITEM", R.drawable.sepatu2)
            startActivity(intent)
        }
        //  bagian 3
        gambar3.setOnClickListener {
            val intent = Intent(this, shopping::class.java)
            intent.putExtra("NAMA_ITEM", item3.text.toString())
            intent.putExtra("HARGA_ITEM", harga3.text.toString())
            intent.putExtra("GAMBAR_ITEM", R.drawable.sepatu4)
            startActivity(intent)
        }

        //bagian 4
        gambar4.setOnClickListener {
            val intent = Intent(this, shopping::class.java)
            intent.putExtra("NAMA_ITEM", item4.text.toString())
            intent.putExtra("HARGA_ITEM", harga4.text.toString())
            intent.putExtra("GAMBAR_ITEM", R.drawable.sepatu7)
            startActivity(intent)
        }
        //bagian 5
        gambar5.setOnClickListener {
            val intent = Intent(this, shopping::class.java)
            intent.putExtra("NAMA_ITEM", item5.text.toString())
            intent.putExtra("HARGA_ITEM", harga5.text.toString())
            intent.putExtra("GAMBAR_ITEM", R.drawable.sepatu8)
            startActivity(intent)
        }

        // bagian 6
        gambar6.setOnClickListener {
            val intent = Intent(this, shopping::class.java)
            intent.putExtra("NAMA_ITEM", item6.text.toString())
            intent.putExtra("HARGA_ITEM", harga6.text.toString())
            intent.putExtra("GAMBAR_ITEM", R.drawable.sepatu10)
            startActivity(intent)
        }
        // bagain 7
        gambar7.setOnClickListener {
            val intent = Intent(this, shopping::class.java)
            intent.putExtra("NAMA_ITEM", item7.text.toString())
            intent.putExtra("HARGA_ITEM", harga7.text.toString())
            intent.putExtra("GAMBAR_ITEM", R.drawable.sepatu11)
            startActivity(intent)
        }
        // bagian 8
        gambar8.setOnClickListener {
            val intent = Intent(this, shopping::class.java)
            intent.putExtra("NAMA_ITEM", item8.text.toString())
            intent.putExtra("HARGA_ITEM", harga8.text.toString())
            intent.putExtra("GAMBAR_ITEM", R.drawable.sepatu12)
            startActivity(intent)
        }
    }
}