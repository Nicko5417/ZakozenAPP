package com.example.empat

import android.app.Dialog
import android.content.Intent
import android.os.Bundle
import android.view.Window
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class shopping : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_shopping)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.shopping)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        val bottomKurang = findViewById<Button>(R.id.buttonKurang)
        val bottomTambah = findViewById<Button>(R.id.buttonTambah)
        val itemcount = findViewById<TextView>(R.id.itemCount)
        val total = findViewById<TextView>(R.id.total)
        val back = findViewById<ImageView>(R.id.back1)



        back.setOnClickListener {
            Intent(this,sepatu::class.java).also {
                startActivity(it)
            }
        }

        val namaItem = intent.getStringExtra("NAMA_ITEM")
        val hargaItem = intent.getStringExtra("HARGA_ITEM")
        val gambarResId = intent.getIntExtra("GAMBAR_ITEM", 0)

        // Setel data ke view
        val itemTextView = findViewById<TextView>(R.id.namaBarang)
        val hargaTextView = findViewById<TextView>(R.id.hargaDetail)
        val gambarImageView = findViewById<ImageView>(R.id.imageView)

        itemTextView.text = namaItem
        hargaTextView.text = hargaItem
        if (gambarResId != 0) {
            gambarImageView.setImageResource(gambarResId)
        }

        //perhitingan
        var count = itemcount.text.toString().toInt()
        val harga = hargaTextView.text.toString().replace("Rp ", "").replace(".", "").toInt()

        // Fungsi untuk memperbarui total
        fun updateTotal() {
            val result = harga * count
            total.text = "Rp. ${String.format("%,d", result)}"
        }

        // Set OnClickListener untuk tombol tambah
        bottomTambah.setOnClickListener {
            count++
            itemcount.text = count.toString()
            updateTotal()
        }

        // Set OnClickListener untuk tombol kurang
        bottomKurang.setOnClickListener {
            if (count > 0) {
                count--
                itemcount.text = count.toString()
                updateTotal()
            }
        }

        // Update pertama kali saat dimulai
        updateTotal()


        // pop up
        val showPopupButton = findViewById<Button>(R.id.btn_show_popup)
        showPopupButton.setOnClickListener {
            showPopupDialog()
        }
    }

    // Function to show pop-up dialog
    private fun showPopupDialog() {
        // Create a Dialog instance
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE) // Remove title
        dialog.setContentView(R.layout.activity_popup_layout) // Set custom layout

        // Find the dismiss button in the pop-up layout and set the click listener
        val dismissButton = dialog.findViewById<Button>(R.id.btn_dismiss)
        dismissButton.setOnClickListener {
            Intent(this,MainActivity::class.java).also {
                startActivity(it)
            }// Close the dialog
        }

        // Show the dialog
        dialog.show()
    }
}