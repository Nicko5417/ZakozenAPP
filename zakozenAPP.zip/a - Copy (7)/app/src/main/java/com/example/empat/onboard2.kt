package com.example.empat

import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class onboard2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_onboard2)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.onboard2)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        val next = findViewById<ImageView>(R.id.illustration)
        next.setOnClickListener {
            Intent(this,onboard3::class.java).also {
                startActivity(it)
            }
        }
        val next1 = findViewById<TextView>(R.id.satu)
        next1.setOnClickListener {
            Intent(this,Login::class.java).also {
                startActivity(it)
            }
        }
    }
}