package com.example.empat

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class qrc : AppCompatActivity() {

    private val CAMERA_REQUEST_CODE = 100

    // Deklarasi ActivityResultLauncher untuk membuka kamera
    private val cameraLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK) {
            // Kamera berhasil terbuka
            Toast.makeText(this, "Kamera terbuka!", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Kamera tidak berhasil terbuka.", Toast.LENGTH_SHORT).show()
            Log.e("CameraError", "Hasil kamera gagal dengan kode: ${result.resultCode}")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_qr)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Navigasi
        val home = findViewById<LinearLayout>(R.id.home1)
        home.setOnClickListener {
            Intent(this, MainActivity::class.java).also {
                startActivity(it)
            }
        }
        val lk = findViewById<LinearLayout>(R.id.lk)
        lk.setOnClickListener {
            Intent(this, like::class.java).also {
                startActivity(it)
            }
        }
        val qr = findViewById<LinearLayout>(R.id.qrcode)
        qr.setOnClickListener {
            Intent(this, qrc::class.java).also {
                startActivity(it)
            }
        }
        val prf = findViewById<LinearLayout>(R.id.prf)
        prf.setOnClickListener {
            Intent(this, profile::class.java).also {
                startActivity(it)
            }
        }

        // Kamera
        val button = findViewById<Button>(R.id.button2)
        button.setOnClickListener {
            requestCameraPermission()
        }
    }

    private fun requestCameraPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), CAMERA_REQUEST_CODE)
        } else {
            openCamera()
        }
    }

    private fun openCamera() {
        val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        if (cameraIntent.resolveActivity(packageManager) != null) {
            cameraLauncher.launch(cameraIntent)
            Log.d("CameraIntent", "Intent kamera diluncurkan.")
        } else {
            Toast.makeText(this, "Aplikasi kamera tidak tersedia.", Toast.LENGTH_SHORT).show()
            Log.e("CameraIntent", "Tidak ada aplikasi kamera yang dapat menangani intent ini.")
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == CAMERA_REQUEST_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                openCamera()
            } else {
                Toast.makeText(this, "Izin kamera diperlukan untuk membuka kamera.", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
