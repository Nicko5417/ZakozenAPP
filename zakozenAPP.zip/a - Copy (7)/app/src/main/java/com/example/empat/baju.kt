package com.example.empat

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class baju : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_baju)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.baju)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        val back = findViewById<Button>(R.id.btnKembalii)

        back.setOnClickListener {
            Intent(this, MainActivity::class.java).also {
                startActivity(it)
            }
        }
        val gambar1 = findViewById<LinearLayout>(R.id.imageBarang)
        val item1 = findViewById<TextView>(R.id.barang1)
        val harga1 = findViewById<TextView>(R.id.hargaDetail)

        val gambar2 = findViewById<LinearLayout>(R.id.imageBarang2)
        val item2 = findViewById<TextView>(R.id.barang2)
        val harga2 = findViewById<TextView>(R.id.hargaDetail2)

        val gambar3 = findViewById<LinearLayout>(R.id.imageBarang3)
        val item3 = findViewById<TextView>(R.id.barang3)
        val harga3 = findViewById<TextView>(R.id.hargaDetail3)

        val gambar4 = findViewById<LinearLayout>(R.id.imageBarang4)
        val item4 = findViewById<TextView>(R.id.barang4)
        val harga4 = findViewById<TextView>(R.id.hargaDetail4)


        //bagian1
        gambar1.setOnClickListener {
            val intent = Intent(this, ShoppingBaju::class.java)
            intent.putExtra("NAMA_ITEM", item1.text.toString())
            intent.putExtra("HARGA_ITEM", harga1.text.toString())
            intent.putExtra("GAMBAR_ITEM", R.drawable.baju1)
            startActivity(intent)
        }
        //bagian 2
        gambar2.setOnClickListener {
            val intent = Intent(this, ShoppingBaju::class.java)
            intent.putExtra("NAMA_ITEM", item2.text.toString())
            intent.putExtra("HARGA_ITEM", harga2.text.toString())
            intent.putExtra("GAMBAR_ITEM", R.drawable.baju2)
            startActivity(intent)
        }
        //  bagian 3
        gambar3.setOnClickListener {
            val intent = Intent(this, ShoppingBaju::class.java)
            intent.putExtra("NAMA_ITEM", item3.text.toString())
            intent.putExtra("HARGA_ITEM", harga3.text.toString())
            intent.putExtra("GAMBAR_ITEM", R.drawable.baju3)
            startActivity(intent)
        }

        //bagian 4
        gambar4.setOnClickListener {
            val intent = Intent(this, ShoppingBaju::class.java)
            intent.putExtra("NAMA_ITEM", item4.text.toString())
            intent.putExtra("HARGA_ITEM", harga4.text.toString())
            intent.putExtra("GAMBAR_ITEM", R.drawable.baju4)
            startActivity(intent)
        }
    }
}